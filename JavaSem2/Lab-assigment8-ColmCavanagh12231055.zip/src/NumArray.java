interface Num {
abstract void neg(); // negation
abstract void sqrt(); // square root
}
