package CourseWorkn;



import java.awt.Dimension;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;


import Lab10.MyTable;

public class Client {

	private static Object email;

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException
	{
		
  Gui colm=new Gui();
colm.setVisible(true);
colm.setSize(500,500);




		
	
	}
	
}













